// Weekly sales email. In Google Sheets: Extensions > Apps Script > paste > save.
// Then: Triggers (clock icon) > Add trigger > sendWeeklySales > Time-driven > Week timer > Monday 8-9 am.
// EDIT the two settings below.
const TO = 'you@example.com';
const SHEET = 'Data';       // name of the tab with your sales
const DATE_COL = 1;         // column number of the Date
const AMOUNT_COL = 8;       // column number of the Amount

function sendWeeklySales() {
  const sh = SpreadsheetApp.getActive().getSheetByName(SHEET);
  const rows = sh.getDataRange().getValues().slice(4);   // data starts on row 5
  const end = new Date(); const start = new Date(end.getTime() - 7 * 86400000);
  let total = 0, orders = 0;
  rows.forEach(r => {
    const d = r[DATE_COL - 1], a = Number(r[AMOUNT_COL - 1]);
    if (d instanceof Date && d >= start && d <= end && !isNaN(a)) { total += a; orders++; }
  });
  const body = 'Sales last 7 days: Rs ' + total.toLocaleString('en-IN') + '\nOrders: ' + orders +
               '\nAverage order: Rs ' + (orders ? Math.round(total / orders) : 0).toLocaleString('en-IN');
  MailApp.sendEmail(TO, 'Weekly sales report', body);
}
