// Google Form > Responses > link to a Sheet. Then in that Sheet:
// Extensions > Apps Script > paste > save > Triggers > Add trigger > onFormSubmit > From spreadsheet > On form submit.
// EDIT the owner email. Replies to the customer automatically and alerts you.
const OWNER = 'you@example.com';

function onFormSubmit(e) {
  const v = e.namedValues;                       // answers keyed by question title
  const name = (v['Name'] || [''])[0], email = (v['Email'] || [''])[0], msg = (v['Message'] || [''])[0];
  MailApp.sendEmail(OWNER, 'New enquiry from ' + name, 'Name: ' + name + '\nEmail: ' + email + '\nMessage: ' + msg);
  if (email) MailApp.sendEmail(email, 'We received your enquiry', 'Hi ' + name + ',\n\nThank you for contacting us. We will reply within one working day.\n\nRegards');
}
