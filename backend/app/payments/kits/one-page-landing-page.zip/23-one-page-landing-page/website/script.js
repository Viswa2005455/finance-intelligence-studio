// Mobile menu, and a gentle fade-in as sections scroll into view
document.addEventListener('DOMContentLoaded', function () {
  var b = document.querySelector('.menu-btn'), u = document.querySelector('nav ul');
  if (b && u) b.addEventListener('click', function () { u.classList.toggle('open'); });
  var y = document.getElementById('yr'); if (y) y.textContent = new Date().getFullYear();
  var items = document.querySelectorAll('.reveal');
  function show(e) { e.classList.add('in'); }
  var vh = window.innerHeight || 800;
  items.forEach(function (e) { if (e.getBoundingClientRect().top < vh * 0.95) show(e); });  // already on screen: show now
  if (!('IntersectionObserver' in window)) { items.forEach(show); return; }
  var io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { show(e.target); io.unobserve(e.target); } }); }, { threshold: 0.12 });
  items.forEach(function (e) { if (!e.classList.contains('in')) io.observe(e); });
  setTimeout(function () { items.forEach(show); }, 6000);  // safety net: never leave content hidden
});
