// Opens and closes the mobile menu
document.addEventListener('DOMContentLoaded', function () {
  var b = document.querySelector('.menu-btn'), u = document.querySelector('nav ul');
  if (b && u) b.addEventListener('click', function () { u.classList.toggle('open'); });
});
