// Mobile menu, and a gentle fade-in as sections scroll into view
document.addEventListener('DOMContentLoaded', function () {
  var b = document.querySelector('.menu-btn'), u = document.querySelector('nav ul');
  if (b && u) b.addEventListener('click', function () { u.classList.toggle('open'); });
  var y = document.getElementById('yr'); if (y) y.textContent = new Date().getFullYear();
  var items = document.querySelectorAll('.reveal');
  if (!('IntersectionObserver' in window)) { items.forEach(function (e) { e.classList.add('in'); }); return; }
  var io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }); }, { threshold: 0.12 });
  items.forEach(function (e) { io.observe(e); });
});
